package com.ty.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ty.entity.Book;
import com.ty.repository.BookRepository;

@Repository
public class BookDao {

	@Autowired
	private BookRepository bookRepository;
	
	public Optional<Book> getBook(Integer bid) {
		return bookRepository.findById(bid);
	}
	
	public List<Book> getBooks() {
		return bookRepository.findAll();
	}
	
	public boolean saveBook(Book book) {
		return bookRepository.save(book)!=null;
	}
	
	public void deleteBook(Integer bid) {
		bookRepository.deleteById(bid);
	}
}
