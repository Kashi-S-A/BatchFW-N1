package com.ty.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ty.entity.Book;

public interface BookRepository extends JpaRepository<Book, Integer>{
	
	//custom method
	List<Book> findByPrice(Double price);
	
	List<Book> findByName(String name);
	
	List<Book> findByNameAndPrice(String name, Double price);
	
	List<Book> findByPriceGreaterThanEqual(Double price);
	
	//custom query
	@Query("select b from Book b where b.price=?1")
	List<Book> giveByPrice(Double price);
	
	@Query("select b from Book b where b.name=:name")
	List<Book> giveByName(String name);
	
	@Query("select b from Book b where b.name=:name and b.price=:price")
	List<Book> giveByNameAndPrice(String name, Double price);
	
    //Native query
	@Query(value = "select * from book where price=?1",nativeQuery = true)
	List<Book> getByPrice(Double price);
}