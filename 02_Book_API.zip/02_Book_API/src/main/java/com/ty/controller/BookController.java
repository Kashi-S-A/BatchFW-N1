package com.ty.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ty.entity.Book;
import com.ty.service.BookService;


@RestController
public class BookController {
	
	@Autowired
	private BookService bookService;

	@GetMapping(value = "/book", produces = { "application/json", "application/xml" })
	public ResponseEntity<Book> getBook(@RequestParam Integer bid) {
		Book book = bookService.getBook(bid);
		return new ResponseEntity<Book>(book,HttpStatus.OK);
	}
	
	@GetMapping(value = "/books",produces = { "application/json", "application/xml" })
	public ResponseEntity<List<Book>> getBooks() {
		List<Book> books = bookService.getBooks();
		return new ResponseEntity<List<Book>>(books, HttpStatus.OK);
	}
	
	@PostMapping(value = "/save", consumes = { "application/json", "application/xml" })
	public ResponseEntity<String> saveBook(@RequestBody Book book) {
		String message = bookService.saveBook(book);
		return new ResponseEntity<String>(message, HttpStatus.CREATED);
	}
	
	@PutMapping(value = "/update/{id}", produces = { "application/json", "application/xml" },
										consumes = { "application/json", "application/xml" }
	)
	public ResponseEntity<?> updateBook(@PathVariable Integer id, @RequestBody Book book) {
		return bookService.updateBook(id, book);
	}

	@DeleteMapping("/delete")
	public ResponseEntity<String> deleteBook(@RequestParam Integer bid) {
		String msg = bookService.deleteById(bid);
		return new ResponseEntity<String>(msg, HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/exe")
	public String getMethodName() {
		
		String s=null;
		
		s.charAt(0);
//		
//		int a=10;
//		int b=0;
//		
//		int c=a/b;
		
		return "Hello";
	}
	
	
//	@GetMapping("/page")
//	public List<Book> getMethodName(@RequestParam Integer pageNumber) {
//	}
//	
//	@GetMapping("/sort")
//	public ResponseEntity<List<Book>> getSortedRecords(@RequestParam String param) {
//	}
	
}
