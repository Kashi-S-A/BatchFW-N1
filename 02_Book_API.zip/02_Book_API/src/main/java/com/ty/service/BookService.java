package com.ty.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ty.dao.BookDao;
import com.ty.entity.Book;
import com.ty.exception.BookNotFoundException;

@Service
public class BookService {

	@Autowired
	private BookDao bookDao;

	public Book getBook(Integer bid) {
		Book book = bookDao.getBook(bid).orElseThrow(() -> new BookNotFoundException("Book does not exist"));
		return book;
	}

	public List<Book> getBooks() {
		return bookDao.getBooks();
	}

	public String saveBook(Book book) {
		boolean saveBook = bookDao.saveBook(book);
		String msg = "";
		if (saveBook) {
			msg = "Saved Successfully";
		} else {
			msg = "Couldn't save please try again later";
		}
		return msg;
	}

	public ResponseEntity<?> updateBook(Integer bid, Book book) {
		Optional<Book> opt = bookDao.getBook(bid);
		if (opt.isPresent()) {
			Book dbBook = opt.get();

			if (book.getName() != null)
				dbBook.setName(book.getName());
			if (book.getPrice() != null)
				dbBook.setPrice(book.getPrice());
			bookDao.saveBook(dbBook);

			return new ResponseEntity<Book>(dbBook, HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Book Not Found", HttpStatus.BAD_REQUEST);
		}

	}
	
	public String deleteById(Integer bid) {
		bookDao.deleteBook(bid);
		return "deleted";
	}
}
