package com.ty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.ty.service.EmailService;

import jakarta.mail.MessagingException;

@SpringBootApplication
public class EmailServiceApplication {

	public static void main(String[] args) throws MessagingException {
		ConfigurableApplicationContext run = SpringApplication.run(EmailServiceApplication.class, args);
		
		EmailService bean = run.getBean(EmailService.class);
		
		String to="ansarisaifali9@gmail.com";
		
		String body="Hi Saif Welcome to App "
				+ "Thank you for choosing our app";
		
		String subject="Registration";
		
//		bean.sendMail(to, body, subject);
		
		String userName="Saif";
		
		bean.sendEmail(to, subject,userName);
		
		System.out.println("email sent");
	}

}
